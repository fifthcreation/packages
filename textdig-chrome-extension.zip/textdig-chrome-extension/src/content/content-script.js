// Copyright 2024 5th Creation (A.K.Mojarrad)
//
// All rights reserved


/**
 * The purpose of this script is to break up selected text into an array of 'blocks'. It does so
 * by traversing the DOM and making a best-guess effort to determine the boundaries of each block.
 * It is not always successful, in which case it returns the text in its original form.
 *
 * This script does not modify the DOM or inject any scripts into the host document.
 */


const LOG_ENABLED = true;

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
   let response;
   switch (message.type) {
     case 'text-selected':
       response = extractTextBlocks(message.selectionText);
       break;
     default:
       response = {error: 'Content: unknown message type: ' + message.type};
   }
   sendResponse(response);
});


function extractTextBlocks(selectionText) {
  log('selectionText', selectionText);
  const range = window.getSelection().getRangeAt(0);

  const commonAncestorContainer = range.commonAncestorContainer.nodeType === Node.TEXT_NODE
      ? range.commonAncestorContainer.parentNode
      : range.commonAncestorContainer;
  log(commonAncestorContainer);

  const starContainer = range.startContainer.nodeType === Node.TEXT_NODE
      ? range.startContainer.parentNode
      : range.startContainer;

  log(starContainer);

  const endContainer = range.endContainer.nodeType === Node.TEXT_NODE
      ? range.endContainer.parentNode
      : range.endContainer;
  log(endContainer);

  const nodeTexts = [];
  const ni = nodeIterator(commonAncestorContainer, starContainer, endContainer);

  while (ni.nextNode()) {
    const n = ni.referenceNode;
    let nodeText;
    if (n.nodeType === Node.TEXT_NODE && (nodeText = n.textContent.trim()).length > 0) {
      const match = matchNodeText(selectionText, nodeText);

      if (match.matched) {
        log('matched: ', '[' + nodeText + ']');
        nodeTexts.push(match.matched);
        selectionText = match.remaining;
      } else {
        log('not matched: ', nodeText);
        log('to match: ', selectionText);
      }
    } else {
      if (n.nodeType === Node.ELEMENT_NODE && nodeTexts.length > 0 && nodeTexts.at(nodeTexts.length - 1) && !isInline(n)) {
        nodeTexts.push(null);
      }
    }
  }
  if (selectionText !== '') {
    nodeTexts.push(selectionText);
  }

  log('-----');
  nodeTexts.forEach(text => log('node text:', text));

  const blocks = textListToBlocks(nodeTexts);

  log('-----');
  blocks.forEach(block => log('text block:', block));
  return blocks;
}

function textListToBlocks(textList) {
  const blocks = [];

  let block = '';
  for (let i = 0; i < textList.length; i++) {
    if (textList[i] == null) {
      blocks.push(block.trim());
      block = '';
    } else {
      block += textList[i];
    }
  }
  if ((block = block.trim()) !== '') {
    blocks.push(block);
  }
  return blocks;
}

function matchNodeText(selectionText, nodeText) {
  const r = startsWithIgnorCaseAndWhitespace(selectionText, nodeText);

  let matched;
  let remaining;
  if (r.startsWith) {
    matched = selectionText.substring(0, r.length);
    remaining = selectionText.substring(r.length);
  } else {
    matched = null;
    remaining = selectionText;
  }

  return {
    matched: matched,
    remaining: remaining
  };
}

function startsWithIgnorCaseAndWhitespace(str, sub) {
  const lowerStr = str.toLowerCase();
  const lowerSub = sub.toLowerCase();
  const startsWith = lowerStr.trim().startsWith(lowerSub);

  return {
    startsWith: startsWith,
    length: startsWith ? lowerStr.indexOf(lowerSub) + lowerSub.length : 0
  };
}

function nodeIterator(node, startContainer, endContainer) {
  return document.createNodeIterator(
      node,
      NodeFilter.SHOW_ALL,
      {
        started: false,
        ended: false,
        inEnd: false,
        acceptNode: function (n) {
          if (n.tagName === 'STYLE' || node.tagName === 'SCRIPT'
              || n.parentElement.tagName === 'STYLE' || n.parentElement.tagName === 'SCRIPT') {
            return NodeFilter.FILTER_SKIP;
          }
          if (n.nodeType === Node.ELEMENT_NODE && n === startContainer) {
            this.started = true;
          } else if (n.nodeType === Node.ELEMENT_NODE && n === endContainer) {
            this.inEnd = true;
          }
          if (this.inEnd && n.nodeType === Node.ELEMENT_NODE && n !== endContainer) {
            this.ended = true;
          }
          if (this.started && !this.ended && isVisible(n.parentElement)) {
            return NodeFilter.FILTER_ACCEPT;
          }
          return NodeFilter.FILTER_SKIP;
        }
      }
  );
}

function isInline(element) {
  return getDisplayType(element).startsWith('inline');
}

function getDisplayType(element) {
  const cStyle = window.getComputedStyle(element, "");
  return cStyle.display;
}

function isVisible(node) {
  return node.nodeType === Node.ELEMENT_NODE && node.checkVisibility();
}

function log(...obj) {
  if (LOG_ENABLED) {
    sendMessage('log', obj);
  }
}

function sendMessage(type, value) {
  chrome.runtime.sendMessage({type: type, value: value})
  .then(r => {
    if (LOG_ENABLED) console.log(r);
  })
  .catch(e => {
    if (LOG_ENABLED) console.log(e);
  });
}
