// Copyright 2024 5th Creation (A.K.Mojarrad)
//
// All rights reserved


/**
 * This script is only active on the product's website. It facilitates communication between the
 * extension and the product.
 */


const LOG_ENABLED = true;

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  let response;
  switch (message.type) {
    case 'set-url':
      log('url', message.value)
      window.open(message.value, '_self')
      response = {ok: true}
      break;
    case 'set-token':
      log('token', message.value)
      setToken(message.value)
      response = {ok: true}
      break;
    default:
      response = {error: 'Content: unknown message type: ' + message.type};
  }
  sendResponse(response);
});

log("TextDig Content script message listener added.");

function log(...obj) {
  if (LOG_ENABLED) {
    sendMessage('log', obj);
  }
}

function sendMessage(type, value) {
  chrome.runtime.sendMessage({type: type, value: value})
  .then(r => {
    if (LOG_ENABLED) console.log(r);
  })
  .catch(e => {
    if (LOG_ENABLED) console.log(e);
  });
}

function addProfileCallback() {
  const e = document.getElementById('profileElement')
  if (e) {
    log('Found profileElement:', e.value);
    if (e.value === '{}' || e.value === '') {
      sendMessage('profile-changed', JSON.parse('{}'));
    }
    e.onchange = () => {
      sendMessage('profile-changed', JSON.parse(e.value));
    }
  } else {
    log('profileElement not found')
  }
}

function setToken(tokenData) {
  log('Setting token data on textdig local storage', tokenData)
  window.localStorage.setItem('sessionId', tokenData.sessionId);
  window.localStorage.setItem('token', tokenData.token);
}

window.addEventListener("load", runMain, false);

function runMain (evt) {
  addProfileCallback();
}
