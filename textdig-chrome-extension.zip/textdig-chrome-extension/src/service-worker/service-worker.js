// Copyright 2024 5th Creation (A.K.Mojarrad)
//
// All rights reserved

/**
 * This script implements the API client to the product backend.
 *
 * It also acts as a message broker between the different screens.
 *
 * The Side Panel and Action screens have been created using Vue. The files generated
 * by Vue have not been minified for review purposes. Source files are available on
 * request.
 *
 */

const LOG_ENABLED = false;

const HOST = 'textdig.fifthcreation.uk';

const TEXT_DIG_TAB_URL_PATTERNS = ["https://" + HOST + "/*"]

const BASE_URL = 'https://' + HOST;

const ERROR_URL = BASE_URL + '/error';


chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  let response;
  switch (message.type) {
    case 'logout':
      logout();
      response = {done: true};
      break;
    case 'open-url':
      openUrl(message.value);
      response = {done: true};
      break;
    case 'add-word':
      addWord(message.value);
      response = {done: true};
      break;
    case 'log':
      logArray(message.value);
      response = {done: true};
      break;
    case 'profile-changed':
      onProfileChange(message.value)
      response = {done: true};
      break;
    default:
      response = {error: 'Service: unknown message type: ' + message.type};
  }
  sendResponse(response);
});


function onProfileChange(profile) {
  if (Object.keys(profile).length === 0 && profile.constructor === Object) {
    deleteProfile();
    deleteCookie('SESSION_ID');
    deleteCookie('TOKEN');
  } else {
    storeProfile(profile);
  }
}


function initContextMenu() {
  chrome.contextMenus.create({
    id: 'dig',
    title: 'Dig',
    contexts: ['selection'],
    enabled: true
  });
}

chrome.runtime.onInstalled.addListener(({reason}) => {
  initContextMenu();
  if (reason === 'install') {
    openUrl(`${BASE_URL}/chrome-install`);
  }
});

chrome.contextMenus.onClicked.addListener((data, tab) => {
  log(data, tab);
  chrome.sidePanel.open({tabId: tab.id})
    .then(() => {
      chrome.i18n.detectLanguage(data.selectionText)
      .then(detected => {
        chrome.tabs.sendMessage(tab.id, {type: "text-selected", selectionText: data.selectionText})
        .then(blocks => getProfile()
          .then(profile => {
            if (profile) {
              analyzeSyntax(escapeSingleQuotesInList(blocks),
                  profile.language, getDetectedLanguage(detected), storeAnalyzeResults)
            }
          }))
        .catch(e => log(e));
      });
    });
});

function getDetectedLanguage(detected) {
  if (detected.isReliable && detected.languages.length > 0) {
    return detected.languages[0].language;
  }
  return null;
}

function deleteCookie(name) {
  chrome.cookies.remove({url: BASE_URL, name: name})
    .then(() => log('Removed cookie:', name));
}

async function getCookie(name){
  const cookies = await chrome.cookies.getAll({domain: HOST, name: name});
  if (!cookies) {
    return null;
  }
  if (cookies.length === 0) {
    return null;
  }
  if (cookies.length === 1 && cookies[0].value !== 'deleted') {
    return cookies[0];
  }
  log(`Found multiple ${name} cookies`, cookies);
  return null;
}

async function getTokenData() {
  const tokenCookie = await getCookie('TOKEN');
  const sIdCookie = await getCookie('SESSION_ID');

  if(tokenCookie && sIdCookie) {
    return {
      sessionId: sIdCookie.value,
      token: tokenCookie.value
    }
  }

  log('Missing sessionId or token cookies', sIdCookie, tokenCookie);
  return null;
}

function joinBlocks(blocks) {
  return blocks.join('\n');
}

function errorHandler(error, status = -1) {
  if (status === 401 || status === 403) {
    deleteProfile();
  } else {
    openErrorPage(error);
  }
}

const callbackHandlerDefaults = {
  onBegin: () => {},
  onEnd: () => {},
  onError: errorHandler,
  onLoginRequired: deleteProfile
}

class RequestCallbacks {
  constructor(onResult = () => {}, handlers = callbackHandlerDefaults) {
    this.promiseResolvers = [];
    this.promise = new Promise((resolve, reject) => {
      this.promiseResolvers.push({ resolve: resolve, reject: reject });
    });
    this.onResult = r => {
      onResult(r);
      if (this.promiseResolvers.length > 0) {
        this.promiseResolvers[0].resolve(r);
      }
    };
    this.onError = (error, status = -1) => {
      if (handlers.onError) {
        handlers.onError(error, status);
      }
      if (this.promiseResolvers.length > 0) {
        this.promiseResolvers[0].resolve(null);
      }
    };
    this.onBegin = () => {
      if (handlers.onBegin) {
        handlers.onBegin();
      }
    }
    this.onEnd = () => {
      if (handlers.onEnd) {
        handlers.onEnd();
      }
    }
    this.onLoginRequired = () => {
      if (handlers.onLoginRequired) {
        handlers.onLoginRequired();
      }
      if (this.promiseResolvers.length > 0) {
        log('on login required, resolving promise with null')
        this.promiseResolvers[0].resolve(null);
      }
    };
  }

  getResultPromise() {
    return this.promise;
  }
}

function requestWithAuth(method, path, callbacks, payload, redirect = "manual") {
  getTokenData()
  .then(tokenData => {
    if (tokenData) {
      log('TokenData: ', tokenData);
      callbacks.onBegin();
      fetch(
          BASE_URL + path,
          {
            method: method,
            headers: {
              'Accept': 'application/json',
              'Content-Type': 'application/json',
              'Authorization': tokenData.token
            },
            body: payload ? JSON.stringify(payload): undefined,
            redirect: redirect
          })
      .then(r => {
        log('Response: ', r);
        callbacks.onEnd();
        if (r.status === 204 || r.status === 202 || r.type === 'opaqueredirect') {
          callbacks.onResult();
        } else if (r.ok) {
          r.json().then(j => {
            if (j.error) {
              callbacks.onError(j.error);
            } else {
              callbacks.onResult(j);
            }
          });
        } else if (r.status === 401) {
          refreshToken(tokenData, () => requestWithAuth(method, path, callbacks, payload));
        } else {
          callbacks.onError(r.statusText, r.status);
        }
      })
      .catch(e => {
        log(e);
        callbacks.onEnd();
        callbacks.onError(e.message);
      });
    } else {
      callbacks.onLoginRequired();
    }
  });
}

function refreshToken(tokenData, continuation) {
  const callbacks = new RequestCallbacks(() => {
    setToken();
    continuation();
  });
  callbacks.onError = (error, status) => {
    if (status === 409) { // conflict
      setTimeout(continuation, 1500);
    } else {
      errorHandler(error, status)
    }
  };
  requestWithoutAuth('POST', '/api/refresh', callbacks, {
    sessionId: tokenData.sessionId,
    token: tokenData.token
  });
}

function requestWithoutAuth(method, path, callbacks, payload, redirect="manual") {
  callbacks.onBegin();
  fetch(
      BASE_URL + path,
      {
        method: method,
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json'
        },
        body: payload ? JSON.stringify(payload) : undefined,
        redirect: redirect
      })
  .then(r => {
    callbacks.onEnd();
    if (r.status === 204 || r.status === 202 || r.type === 'opaqueredirect') {
      callbacks.onResult();
    } else if (r.ok) {
      r.json().then(j => {
        if (j.error) {
          callbacks.onError(j.error);
        } else {
          callbacks.onResult(j);
        }
      });
    } else {
      callbacks.onError(r.statusText, r.status);
    }
  }).catch(e => {
    log(e);
    callbacks.onEnd();
    callbacks.onError(e.message);
  });
}

function analyzeSyntax(textBlocks, lang, textLang, resultConsumer) {
  const text = joinBlocks(textBlocks);
  log('Calling backend with text: ' + text);

  const handlers = { ...callbackHandlerDefaults }
  handlers.onBegin = loaderOn;
  handlers.onEnd = loaderOff;

  const callbacks = new RequestCallbacks(resultConsumer, handlers);

  requestWithAuth('POST', '/process/analysis', callbacks, {
    origin: 'chrome',
    translateLanguage: lang,
    language: textLang,
    textBlocks: textBlocks
  });
}

function logout() {
  log('Logging out...');
  getTokenData()
  .then(tokenData => {
    if (tokenData) {
      log('TokenData: ', tokenData);
      requestWithoutAuth('POST', '/api/logout', new RequestCallbacks(doAfterLogout), {
        sessionId: tokenData.sessionId,
        token: tokenData.token
      });
    } else {
      log('Already logged out')
    }
  });
}

function doAfterLogout(rsp) {
  deleteProfile();
  openUrl(rsp.redirectUrl);
}

function addWord(obj) {
  const lang = obj.language;
  const word = obj.word;

  log('Adding word: ', lang, word);

  requestWithAuth('POST', '/api/word', new RequestCallbacks(), {
    language: lang,
    word: word
  });
}


function getProfile() {
  return chrome.storage.session.get('profile')
  .then(p => {
    log('Profile from store: ', p);
    return p['profile'];
  });
}

function storeProfile(p) {
  return chrome.storage.session.set({
    'profile': p
  }).then(() => p);
}

function deleteProfile() {
  chrome.storage.session.remove('profile')
  .then(() => log('Deleted profile: '));
}

function openErrorPage(error) {
  openUrl(ERROR_URL + '?error=' + error);
}

function loaderOn() {
  sendMessage("loader-on");
}

function loaderOff() {
  sendMessage("loader-off");
}

function sendMessage(type, value) {
  chrome.runtime.sendMessage({type: type, value: value})
  .then(r => log(r))
  .catch(e => log(e));
}

function storeAnalyzeResults(responsePayload) {
  chrome.storage.session.set({
    'lastSelection': responsePayload
  }).then(unused => log('Result added'));
}


function setToken() {
  getFirstTextDigTab()
  .then(tab => {
        if (tab) {
          getTokenData().then(tokenData => {
            if (tokenData) {
              chrome.tabs.sendMessage(tab.id, {type: "set-token", value: tokenData})
              .then(r => log(r));
            }
          })
        }
      }
  );
}

function openUrl(url) {
  getFirstTextDigTab()
    .then(tab => {
      if (tab) {
        log('Found textdig tab: ', tab)
        chrome.tabs.update(tab.id, { 'active': true })
        .then(() => chrome.tabs.sendMessage(tab.id, {type: 'set-url', value: url})
          .then(() => log('Opened in existing tab', url, tab)))
        .catch(() => openInNewTab(url)
          .then(tab => log('Opened in new tab on error', url, tab)))
      } else {
        openInNewTab(url)
          .then(tab => log('Opened in new tab', url, tab));
      }
    });
}

function openInNewTab(url) {
  return chrome.tabs.create({
    url: url
  });
}

async function getFirstTextDigTab(){
  let queryOptions = {
    url: TEXT_DIG_TAB_URL_PATTERNS
  };
  let [tab] = await chrome.tabs.query(queryOptions);
  return tab;
}


function escapeSingleQuotesInList(list) {
  for (let i = 0; i < list.length; i++) {
    list[i] = list[i].replaceAll("'", "&apos;");
  }
  return list
}

function logArray(obj) {
  if (LOG_ENABLED) {
    console.log(...obj);
  }
}

function log(...obj) {
  if (LOG_ENABLED) {
    console.log(...obj);
  }
}
