import { _ as _export_sfc, e as openBlock, c as createElementBlock, a as createBaseVNode, u as useI18n, i as inject, L as Logger, r as ref, w as watch, g as getUILanguage, o as onMounted, y as createVNode, b as unref, t as toDisplayString, n as normalizeClass, z as createCommentVNode, F as Fragment, A as renderList, s as sendMessage, B as BASE_URL, C as resolveComponent, d as createTextVNode, f as createApp, h as createI18n, j as entry_esm, k as en, l as es, m as nl, p as de, q as fr, v as it, x as pt } from "../../pt-DdK4OeCS.js";
const _sfc_main$1 = {};
const _hoisted_1$1 = {
  xmlns: "http://www.w3.org/2000/svg",
  width: "16",
  height: "16",
  fill: "currentColor",
  class: "bi bi-arrow-right",
  viewBox: "0 0 16 16"
};
function _sfc_render(_ctx, _cache) {
  return openBlock(), createElementBlock("svg", _hoisted_1$1, _cache[0] || (_cache[0] = [
    createBaseVNode("path", {
      "fill-rule": "evenodd",
      d: "M1 8a.5.5 0 0 1 .5-.5h11.793l-3.147-3.146a.5.5 0 0 1 .708-.708l4 4a.5.5 0 0 1 0 .708l-4 4a.5.5 0 0 1-.708-.708L13.293 8.5H1.5A.5.5 0 0 1 1 8"
    }, null, -1)
  ]));
}
const ArrowRight = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["render", _sfc_render]]);
const GLOSBE_URL_TEMPLATE = `https://glosbe.com/[fromLang]/[toLang]/[word]`;
const LanguageFlagMap = {
  en: "gb",
  es: "es",
  de: "de",
  nl: "nl",
  fr: "fr",
  it: "it",
  pt: "pt"
};
function getWordOpenUrl(toLang, fromLang, word) {
  return GLOSBE_URL_TEMPLATE.replace("[fromLang]", fromLang).replace("[toLang]", toLang).replace("[word]", encodeURIComponent(word));
}
function openDict(toLang, fromLang, text) {
  if (toLang && fromLang && text) {
    window.open(getWordOpenUrl(toLang, fromLang, text), text);
  }
}
function getNumSpaces(tokens, i) {
  if (i >= tokens.length - 1) {
    return 1;
  }
  return tokens[i + 1].StartPosition - tokens[i].EndPosition;
}
function wordEnter(event, token) {
  const popup = event.target.querySelector(".popup");
  popup.classList.add("show");
}
function wordLeave(event, token) {
  const popup = event.target.querySelector(".popup");
  popup.classList.remove("show");
}
function getClassListForWordPos(pos) {
  switch (pos) {
    case "ADJ":
      return ["dotted-underline", "pointer", "adjective"];
    case "ADP":
      return ["dotted-underline", "pointer", "adposition"];
    case "ADV":
      return ["dotted-underline", "pointer", "adverb"];
    case "AUX":
      return ["dotted-underline", "pointer", "auxiliary"];
    case "CCONJ":
      return ["dotted-underline", "pointer", "coordinating-conjunction"];
    case "CONJ":
      return ["dotted-underline", "pointer", "conjunction"];
    case "DET":
      return ["dotted-underline", "pointer", "determiner"];
    case "INTJ":
      return ["dotted-underline", "pointer", "interjection"];
    case "NOUN":
      return ["dotted-underline", "pointer", "noun"];
    case "PART":
      return ["dotted-underline", "pointer", "particle"];
    case "PRON":
      return ["dotted-underline", "pointer", "pronoun"];
    case "PROPN":
      return ["dotted-underline", "pointer", "proper-noun"];
    case "SCONJ":
      return ["dotted-underline", "pointer", "subordinating-conjunction"];
    case "VERB":
      return ["dotted-underline", "pointer", "verb"];
    default:
      return ["dotted-underline", "all-words"];
  }
}
function stringToDate(date) {
  if (!date.endsWith("Z")) {
    date = date + "Z";
  }
  return new Date(Date.parse(date));
}
function formatDatetime(date) {
  if (typeof date === "string") {
    return stringToDate(date).toLocaleString();
  }
  if (date instanceof Date) {
    return date.toLocaleString();
  }
  return "";
}
const _hoisted_1 = { class: "container p-3" };
const _hoisted_2 = {
  key: 0,
  class: "card-header mb-2 d-flex"
};
const _hoisted_3 = { class: "justify-content-start align-content-center pointer m-1" };
const _hoisted_4 = { class: "align-text-top fw-bold" };
const _hoisted_5 = { class: "justify-content-end flex-grow-1" };
const _hoisted_6 = {
  key: 1,
  class: "card-header mb-2 d-flex"
};
const _hoisted_7 = { class: "justify-content-start align-content-center pointer m-1" };
const _hoisted_8 = ["id"];
const _hoisted_9 = { class: "card-header" };
const _hoisted_10 = { class: "flex-row d-flex justify-content-start" };
const _hoisted_11 = ["onClick"];
const _hoisted_12 = ["onClick"];
const _hoisted_13 = ["onClick"];
const _hoisted_14 = ["id"];
const _hoisted_15 = ["id"];
const _hoisted_16 = ["id", "onMouseenter", "onMouseleave", "onClick"];
const _hoisted_17 = { class: "popup" };
const _hoisted_18 = { class: "d-block" };
const _hoisted_19 = {
  key: 0,
  class: "d-block"
};
const _hoisted_20 = {
  key: 1,
  class: "d-block"
};
const _hoisted_21 = ["id"];
const _hoisted_22 = { class: "text-danger pointer" };
const _hoisted_23 = { key: 0 };
const _hoisted_24 = ["id"];
const _hoisted_25 = { class: "text-primary font-bold pointer" };
const _hoisted_26 = { key: 0 };
const _sfc_main = {
  __name: "SidePanel",
  setup(__props) {
    const EXCLUDE_KEYS_FROM_STORAGE_TRIM = ["profile", "lastSelection"];
    const { t, locale } = useI18n();
    const logger = inject(Logger.KEY);
    const profile = ref();
    const digs = ref([]);
    const loaderOn = ref(false);
    const langKey = ref("");
    watch(
      () => {
        var _a;
        return (_a = profile.value) == null ? void 0 : _a.language;
      },
      (lang) => {
        if (lang) {
          locale.value = lang;
        } else {
          locale.value = "en";
        }
      },
      { deep: false }
    );
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
      let response;
      switch (message.type) {
        case "loader-on":
          loaderOn.value = true;
          response = { done: true };
          break;
        case "loader-off":
          loaderOn.value = false;
          response = { done: true };
          break;
        default:
          response = { error: "Side panel: unknown message type: " + message.type };
      }
      sendResponse(response);
    });
    chrome.storage.session.onChanged.addListener((changes) => {
      let change = changes["lastSelection"];
      if (change) {
        handleSelectionChange(change.newValue);
      }
      change = changes["profile"];
      if (change) {
        handleProfileChange(change.newValue);
      }
    });
    function handleProfileChange(p) {
      logger.log("Changed [profile]", p);
      profile.value = p;
      if (p) {
        langKey.value = `${p.userId}_${p.language}_${p.learningLanguage}`;
        trimDigsNotBelongingToUser(p.userId);
      } else {
        langKey.value = "";
        locale.value = getUILanguage();
      }
      loadDigs();
      logger.log("langKey: ", langKey.value);
    }
    function handleSelectionChange(newValue) {
      logger.log("Changed [lastSelection]", newValue);
      if (langKey.value) {
        chrome.storage.session.get(langKey.value).then((val) => {
          logger.log("Dig stored in session: ", val);
          let arr = val[langKey.value];
          if (!arr) {
            arr = [];
          }
          arr.unshift(newValue);
          putDigsInStorage(langKey.value, arr);
        });
      }
    }
    function loadDigs() {
      return chrome.storage.session.get(langKey.value).then((value) => {
        logger.log("getDigs: ", value);
        digs.value = value[langKey.value];
      });
    }
    onMounted(() => {
      chrome.storage.session.get("profile").then((p) => {
        handleProfileChange(p["profile"]);
        loadDigs();
      });
    });
    function putDigsInStorage(key, digArr, keepNumElements = 5) {
      chrome.storage.session.set({ [key]: digArr }).then(() => {
        if (chrome.runtime.lastError) {
          trimDigsInStorage(keepNumElements).then(() => putDigsInStorage(key, digArr, keepNumElements - 2));
        } else {
          loadDigs();
        }
      });
    }
    function trimDigsNotBelongingToUser(userId) {
      return chrome.storage.session.get(null).then((all) => {
        const langKeys = Object.keys(all).filter((k) => !EXCLUDE_KEYS_FROM_STORAGE_TRIM.includes(k));
        langKeys.forEach((key) => {
          if (!key.startsWith(userId)) {
            chrome.storage.session.remove(key).then(() => logger.log("Trimmed other user digs: ", key));
          }
        });
      });
    }
    function trimDigsInStorage(keepNumElements) {
      return chrome.storage.session.get(null).then((all) => {
        const langKeys = Object.keys(all).filter((k) => !EXCLUDE_KEYS_FROM_STORAGE_TRIM.includes(k));
        langKeys.forEach((key) => {
          let arr = all[key];
          if (arr.length > keepNumElements) {
            arr = arr.slice(0, keepNumElements);
            chrome.storage.session.remove(key).then(() => chrome.storage.session.set({ [key]: arr }).then(() => logger.log("Trimmed: ", key)));
          }
        });
      });
    }
    function addWord(word) {
      sendMessage("add-word", { language: profile.value.learningLanguage, word });
    }
    function wordClick(event, token) {
      if (profile.value) {
        openDict(profile.value.language, profile.value.learningLanguage, token.Text);
        addWord(token.Lemma);
      }
    }
    const selectedDigView = ref({});
    function getSelectedDigView(digId) {
      const val = selectedDigView.value[digId];
      if (val) {
        return val;
      }
      return "syntax";
    }
    function getSliceStartPoints(entities, i) {
      if (i === 0) {
        return 0;
      }
      return entities[i - 1].End;
    }
    function openEditProfile() {
      sendMessage("open-url", `${BASE_URL}/profile`);
    }
    function login() {
      sendMessage("open-url", `${BASE_URL}/api/login`);
    }
    return (_ctx, _cache) => {
      var _a, _b, _c;
      const _component_country_flag = resolveComponent("country-flag");
      return openBlock(), createElementBlock("div", _hoisted_1, [
        profile.value ? (openBlock(), createElementBlock("div", _hoisted_2, [
          createBaseVNode("div", {
            class: "justify-content-start align-content-center pointer m-1",
            onClick: _cache[0] || (_cache[0] = ($event) => openEditProfile())
          }, [
            createVNode(_component_country_flag, {
              country: unref(LanguageFlagMap)[(_a = profile.value) == null ? void 0 : _a.language],
              size: "normal",
              rounded: "true",
              shadow: "true"
            }, null, 8, ["country"])
          ]),
          createBaseVNode("div", {
            class: "justify-content-start align-content-center pointer",
            onClick: _cache[1] || (_cache[1] = ($event) => openEditProfile())
          }, [
            createVNode(ArrowRight)
          ]),
          createBaseVNode("div", {
            class: "justify-content-start align-content-center pointer m-1",
            onClick: _cache[2] || (_cache[2] = ($event) => openEditProfile())
          }, [
            createVNode(_component_country_flag, {
              country: unref(LanguageFlagMap)[(_b = profile.value) == null ? void 0 : _b.learningLanguage],
              size: "normal",
              rounded: "true",
              shadow: "true"
            }, null, 8, ["country"])
          ]),
          createBaseVNode("div", _hoisted_3, [
            createBaseVNode("span", _hoisted_4, toDisplayString(unref(t)("sidePanel.profile.subscription." + ((_c = profile.value) == null ? void 0 : _c.subscriptionType))), 1)
          ]),
          createBaseVNode("div", _hoisted_5, [
            createBaseVNode("div", {
              class: normalizeClass(["float-end", loaderOn.value ? "loader" : ""])
            }, null, 2)
          ])
        ])) : createCommentVNode("", true),
        !profile.value ? (openBlock(), createElementBlock("div", _hoisted_6, [
          createBaseVNode("div", _hoisted_7, [
            createBaseVNode("button", {
              id: "login",
              class: "btn btn-warning",
              onClick: _cache[3] || (_cache[3] = ($event) => login())
            }, toDisplayString(unref(t)("user.login")), 1)
          ])
        ])) : createCommentVNode("", true),
        profile.value ? (openBlock(true), createElementBlock(Fragment, { key: 2 }, renderList(digs.value, (item, di) => {
          return openBlock(), createElementBlock("div", {
            id: `dig_${item.result.digest}`,
            class: "card mb-2"
          }, [
            createBaseVNode("div", _hoisted_9, [
              createBaseVNode("div", null, [
                createBaseVNode("h5", null, toDisplayString(unref(formatDatetime)(item.result.date)), 1)
              ]),
              createBaseVNode("div", _hoisted_10, [
                createBaseVNode("button", {
                  type: "button",
                  class: normalizeClass(["btn btn-outline-success btn-sm me-2", getSelectedDigView(`dig_${item.result.digest}`) === "syntax" ? "active" : ""]),
                  onClick: ($event) => selectedDigView.value[`dig_${item.result.digest}`] = "syntax"
                }, toDisplayString(unref(t)("sidePanel.digResult.syntax")), 11, _hoisted_11),
                createBaseVNode("button", {
                  type: "button",
                  class: normalizeClass(["btn btn-outline-danger btn-sm me-2", getSelectedDigView(`dig_${item.result.digest}`) === "phrases" ? "active" : ""]),
                  onClick: ($event) => selectedDigView.value[`dig_${item.result.digest}`] = "phrases"
                }, toDisplayString(unref(t)("sidePanel.digResult.phrases")), 11, _hoisted_12),
                createBaseVNode("button", {
                  type: "button",
                  class: normalizeClass(["btn btn-outline-primary btn-sm me-2", getSelectedDigView(`dig_${item.result.digest}`) === "entities" ? "active" : ""]),
                  onClick: ($event) => selectedDigView.value[`dig_${item.result.digest}`] = "entities"
                }, toDisplayString(unref(t)("sidePanel.digResult.entities")), 11, _hoisted_13)
              ])
            ]),
            (openBlock(true), createElementBlock(Fragment, null, renderList(item.result.ProcessOutput.spacy.TextBlocks, (block, bi) => {
              return openBlock(), createElementBlock("div", {
                id: `block_${di}_${bi}`,
                class: "card-body p-0 ps-3 pt-3"
              }, [
                createBaseVNode("div", {
                  id: `syntax_${di}_${bi}`,
                  class: normalizeClass(getSelectedDigView(`dig_${item.result.digest}`) === "syntax" ? "d-block" : "d-none")
                }, [
                  createBaseVNode("p", null, [
                    (openBlock(true), createElementBlock(Fragment, null, renderList(block.Analysis.Tokens, (token, ti) => {
                      return openBlock(), createElementBlock("span", {
                        id: `syntax_token_${di}_${bi}_${ti}`,
                        class: "word-container",
                        onMouseenter: (event) => unref(wordEnter)(event, token),
                        onMouseleave: (event) => unref(wordLeave)(event, token),
                        onClick: (event) => wordClick(event, token)
                      }, [
                        createBaseVNode("span", {
                          class: normalizeClass(unref(getClassListForWordPos)(token.POS))
                        }, toDisplayString(token.Text + " ".repeat(unref(getNumSpaces)(block.Analysis.Tokens, ti))), 3),
                        createBaseVNode("span", _hoisted_17, [
                          createBaseVNode("span", _hoisted_18, toDisplayString(unref(t)("language.pos." + token.POS)), 1),
                          token.Text !== token.Lemma ? (openBlock(), createElementBlock("span", _hoisted_19, "Lemmatization: " + toDisplayString(token.Lemma), 1)) : createCommentVNode("", true),
                          token.MorphologyStr ? (openBlock(), createElementBlock("span", _hoisted_20, "Morphology: " + toDisplayString(token.MorphologyStr), 1)) : createCommentVNode("", true)
                        ])
                      ], 40, _hoisted_16);
                    }), 256))
                  ])
                ], 10, _hoisted_15),
                createBaseVNode("div", {
                  id: `phrases_${di}_${bi}`,
                  class: normalizeClass(getSelectedDigView(`dig_${item.result.digest}`) === "phrases" ? "d-block" : "d-none")
                }, [
                  createBaseVNode("p", null, [
                    (openBlock(true), createElementBlock(Fragment, null, renderList(block.Analysis.NounChunks, (span, si) => {
                      return openBlock(), createElementBlock(Fragment, null, [
                        createBaseVNode("span", null, [
                          (openBlock(true), createElementBlock(Fragment, null, renderList(block.Analysis.Tokens.slice(getSliceStartPoints(block.Analysis.NounChunks, si), span.Start), (token, ti) => {
                            return openBlock(), createElementBlock(Fragment, null, [
                              createTextVNode(toDisplayString(token.Text + " ".repeat(unref(getNumSpaces)(block.Analysis.Tokens, ti + getSliceStartPoints(block.Analysis.NounChunks, si)))), 1)
                            ], 64);
                          }), 256))
                        ]),
                        createBaseVNode("span", _hoisted_22, [
                          (openBlock(true), createElementBlock(Fragment, null, renderList(block.Analysis.Tokens.slice(span.Start, span.End), (token, ti) => {
                            return openBlock(), createElementBlock(Fragment, null, [
                              createTextVNode(toDisplayString(token.Text + " ".repeat(unref(getNumSpaces)(block.Analysis.Tokens, ti + span.Start))), 1)
                            ], 64);
                          }), 256))
                        ]),
                        si === block.Analysis.NounChunks.length - 1 ? (openBlock(), createElementBlock("span", _hoisted_23, [
                          (openBlock(true), createElementBlock(Fragment, null, renderList(block.Analysis.Tokens.slice(span.End), (token, ti) => {
                            return openBlock(), createElementBlock(Fragment, null, [
                              createTextVNode(toDisplayString(token.Text + " ".repeat(unref(getNumSpaces)(block.Analysis.Tokens, ti + span.End))), 1)
                            ], 64);
                          }), 256))
                        ])) : createCommentVNode("", true)
                      ], 64);
                    }), 256)),
                    block.Analysis.NounChunks.length === 0 ? (openBlock(true), createElementBlock(Fragment, { key: 0 }, renderList(block.Analysis.Tokens, (token, ti) => {
                      return openBlock(), createElementBlock(Fragment, null, [
                        createTextVNode(toDisplayString(token.Text + " ".repeat(unref(getNumSpaces)(block.Analysis.Tokens, ti))), 1)
                      ], 64);
                    }), 256)) : createCommentVNode("", true)
                  ])
                ], 10, _hoisted_21),
                createBaseVNode("div", {
                  id: `entities_${di}_${bi}`,
                  class: normalizeClass(getSelectedDigView(`dig_${item.result.digest}`) === "entities" ? "d-block" : "d-none")
                }, [
                  createBaseVNode("p", null, [
                    (openBlock(true), createElementBlock(Fragment, null, renderList(block.Analysis.Entities, (span, si) => {
                      return openBlock(), createElementBlock(Fragment, null, [
                        createBaseVNode("span", null, [
                          (openBlock(true), createElementBlock(Fragment, null, renderList(block.Analysis.Tokens.slice(getSliceStartPoints(block.Analysis.Entities, si), span.Start), (token, ti) => {
                            return openBlock(), createElementBlock(Fragment, null, [
                              createTextVNode(toDisplayString(token.Text + " ".repeat(unref(getNumSpaces)(block.Analysis.Tokens, ti + getSliceStartPoints(block.Analysis.Entities, si)))), 1)
                            ], 64);
                          }), 256))
                        ]),
                        createBaseVNode("span", _hoisted_25, [
                          (openBlock(true), createElementBlock(Fragment, null, renderList(block.Analysis.Tokens.slice(span.Start, span.End), (token, ti) => {
                            return openBlock(), createElementBlock(Fragment, null, [
                              createTextVNode(toDisplayString(token.Text + " ".repeat(unref(getNumSpaces)(block.Analysis.Tokens, ti + span.Start))), 1)
                            ], 64);
                          }), 256))
                        ]),
                        si === block.Analysis.Entities.length - 1 ? (openBlock(), createElementBlock("span", _hoisted_26, [
                          (openBlock(true), createElementBlock(Fragment, null, renderList(block.Analysis.Tokens.slice(span.End), (token, ti) => {
                            return openBlock(), createElementBlock(Fragment, null, [
                              createTextVNode(toDisplayString(token.Text + " ".repeat(unref(getNumSpaces)(block.Analysis.Tokens, ti + span.End))), 1)
                            ], 64);
                          }), 256))
                        ])) : createCommentVNode("", true)
                      ], 64);
                    }), 256)),
                    block.Analysis.Entities.length === 0 ? (openBlock(true), createElementBlock(Fragment, { key: 0 }, renderList(block.Analysis.Tokens, (token, ti) => {
                      return openBlock(), createElementBlock(Fragment, null, [
                        createTextVNode(toDisplayString(token.Text + " ".repeat(unref(getNumSpaces)(block.Analysis.Tokens, ti))), 1)
                      ], 64);
                    }), 256)) : createCommentVNode("", true)
                  ])
                ], 10, _hoisted_24),
                createBaseVNode("p", null, toDisplayString(item.result.ProcessOutput.translate.translations[bi].text), 1)
              ], 8, _hoisted_14);
            }), 256))
          ], 8, _hoisted_8);
        }), 256)) : createCommentVNode("", true)
      ]);
    };
  }
};
const App = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-db75ea24"]]);
const LOG_ENABLED = "true";
const app = createApp(App);
const i18n = createI18n({
  locale: navigator.language,
  fallbackLocale: "en",
  messages: { en, es, nl, de, fr, it, pt },
  legacy: false
});
app.use(i18n);
app.use(entry_esm);
app.provide(Logger.KEY, new Logger(LOG_ENABLED));
app.mount("#app");
