import { _ as _export_sfc, u as useI18n, i as inject, L as Logger, r as ref, w as watch, g as getUILanguage, o as onMounted, c as createElementBlock, a as createBaseVNode, n as normalizeClass, t as toDisplayString, b as unref, d as createTextVNode, s as sendMessage, B as BASE_URL, e as openBlock, f as createApp, h as createI18n, j as entry_esm, k as en, l as es, m as nl, p as de, q as fr, v as it, x as pt } from "../../pt-DdK4OeCS.js";
const _hoisted_1 = { class: "main-area" };
const _hoisted_2 = { class: "card p-1" };
const _hoisted_3 = { class: "card-body m-2" };
const _hoisted_4 = { class: "m-2" };
const _hoisted_5 = { class: "m-2 text-primary" };
const _sfc_main = {
  __name: "Toolbar",
  setup(__props) {
    const { locale, t } = useI18n();
    const logger = inject(Logger.KEY);
    const profile = ref();
    chrome.storage.session.onChanged.addListener((changes) => {
      const change = changes["profile"];
      if (change) {
        handleProfileChange(change.newValue);
      }
    });
    watch(
      () => {
        var _a;
        return (_a = profile.value) == null ? void 0 : _a.language;
      },
      (lang) => {
        if (lang) {
          locale.value = lang;
        } else {
          locale.value = "en";
        }
      },
      { deep: false }
    );
    function handleProfileChange(p) {
      logger.log("Changed [profile]", p);
      profile.value = p;
      if (!p) {
        locale.value = getUILanguage();
      }
    }
    function logout() {
      sendMessage("logout");
    }
    function login() {
      sendMessage("open-url", `${BASE_URL}/api/login`);
    }
    function openHelp() {
      sendMessage("open-url", `${BASE_URL}/browser-extension`);
    }
    onMounted(() => {
      chrome.storage.session.get("profile").then((p) => {
        handleProfileChange(p["profile"]);
      });
    });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("main", null, [
        createBaseVNode("div", _hoisted_1, [
          createBaseVNode("div", _hoisted_2, [
            _cache[3] || (_cache[3] = createBaseVNode("div", { class: "card-header m-2" }, [
              createBaseVNode("h1", null, "TextDig")
            ], -1)),
            createBaseVNode("div", _hoisted_3, [
              createBaseVNode("button", {
                id: "login",
                class: normalizeClass(["btn btn-warning", !profile.value ? "" : "d-none"]),
                onClick: _cache[0] || (_cache[0] = ($event) => login())
              }, toDisplayString(unref(t)("user.login")), 3),
              createBaseVNode("button", {
                id: "logout",
                class: normalizeClass(["btn btn-dark", profile.value ? "" : "d-none"]),
                onClick: _cache[1] || (_cache[1] = ($event) => logout())
              }, toDisplayString(unref(t)("user.logout")), 3)
            ]),
            createBaseVNode("div", _hoisted_4, toDisplayString(unref(t)("help.tipMessage")), 1),
            createBaseVNode("div", _hoisted_5, [
              createBaseVNode("strong", null, [
                createTextVNode(toDisplayString(unref(t)("help.moreInfo")) + " TextDig ", 1),
                createBaseVNode("a", {
                  href: "#",
                  class: "fw-bold",
                  onClick: _cache[2] || (_cache[2] = ($event) => openHelp())
                }, toDisplayString(unref(t)("help.website")), 1)
              ])
            ])
          ])
        ])
      ]);
    };
  }
};
const App = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-d0cc2cdc"]]);
const LOG_ENABLED = "true";
const app = createApp(App);
const i18n = createI18n({
  locale: navigator.language,
  fallbackLocale: "en",
  messages: { en, es, nl, de, fr, it, pt },
  legacy: false
});
app.use(i18n);
app.use(entry_esm);
app.provide(Logger.KEY, new Logger(LOG_ENABLED));
app.mount("#app");
