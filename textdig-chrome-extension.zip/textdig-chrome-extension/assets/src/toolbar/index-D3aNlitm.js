import { _ as _export_sfc, u as useI18n, i as inject, L as Logger, r as ref, w as watch, g as getUILanguage, o as onMounted, c as createElementBlock, a as createBaseVNode, n as normalizeClass, t as toDisplayString, b as unref, d as createTextVNode, e as createVNode, f as createCommentVNode, s as sendMessage, B as BASE_URL, h as openBlock, A as Alert, j as createApp, k as createI18n, l as en, m as es, p as nl, q as de, v as fr, x as it, y as pt, z as entry_esm } from "../../pt-B58WKgKt.js";
const _hoisted_1 = { class: "main-area" };
const _hoisted_2 = { class: "card p-1" };
const _hoisted_3 = { class: "d-flex flex-row justify-content-start card-body m-2" };
const _hoisted_4 = { class: "p-2" };
const _hoisted_5 = { class: "p-2" };
const _hoisted_6 = { class: "m-2" };
const _hoisted_7 = { class: "m-2 text-primary" };
const _hoisted_8 = {
  key: 0,
  class: "d-flex flex-row justify-content-start card-body"
};
const _hoisted_9 = {
  class: "alert alert-danger flex-grow-1",
  role: "alert"
};
const _sfc_main = {
  __name: "Toolbar",
  setup(__props) {
    const { locale, t } = useI18n();
    const logger = inject(Logger.KEY);
    const profile = ref();
    const langKey = ref("");
    const lastError = ref("");
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
      let response;
      switch (message.type) {
        case "on-req-begin":
          lastError.value = "";
          response = { done: true };
          break;
        case "on-req-end":
          lastError.value = "";
          response = { done: true };
          break;
        case "on-fetch-error":
          lastError.value = t("error.fetch");
          response = { done: true };
          break;
        case "on-sys-error":
          lastError.value = t("error.sys", { err: message.value });
          response = { done: true };
          break;
        default:
          response = { error: "Side panel: unknown message type: " + message.type };
      }
      sendResponse(response);
    });
    chrome.storage.session.onChanged.addListener((changes) => {
      const change = changes["profile"];
      if (change) {
        handleProfileChange(change.newValue);
      }
    });
    watch(
      () => {
        var _a;
        return (_a = profile.value) == null ? void 0 : _a.language;
      },
      (lang) => {
        if (lang) {
          locale.value = lang;
        } else {
          locale.value = "en";
        }
      },
      { deep: false }
    );
    function handleProfileChange(p) {
      logger.log("Changed [profile]", p);
      profile.value = p;
      if (p) {
        langKey.value = `${p.userId}_${p.language}_${p.learningLanguage}`;
      } else {
        langKey.value = "";
        locale.value = getUILanguage();
      }
      logger.log("langKey: ", langKey.value);
    }
    function logout() {
      sendMessage("logout");
    }
    function login() {
      sendMessage("login");
    }
    function openHelp() {
      const version = chrome.runtime.getManifest().version;
      sendMessage("open-url", `${BASE_URL}/browser-extension?b=chrome&a=help&v=${version}`);
    }
    function clearLocalHistory() {
      if (profile.value) {
        chrome.storage.session.set({ [langKey.value]: [] }).then(() => chrome.storage.session.set({ "lastSelection": {} }));
      }
    }
    onMounted(() => {
      chrome.storage.session.get("profile").then((p) => {
        handleProfileChange(p["profile"]);
      });
      lastError.value = false;
    });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("main", null, [
        createBaseVNode("div", _hoisted_1, [
          createBaseVNode("div", _hoisted_2, [
            _cache[4] || (_cache[4] = createBaseVNode("div", { class: "card-header m-2" }, [
              createBaseVNode("h1", null, "TextDig")
            ], -1)),
            createBaseVNode("div", _hoisted_3, [
              createBaseVNode("div", _hoisted_4, [
                createBaseVNode("button", {
                  class: normalizeClass(["btn btn-warning", !profile.value ? "" : "d-none"]),
                  onClick: _cache[0] || (_cache[0] = ($event) => login())
                }, toDisplayString(unref(t)("user.login")), 3),
                createBaseVNode("button", {
                  class: normalizeClass(["btn btn-dark", profile.value ? "" : "d-none"]),
                  onClick: _cache[1] || (_cache[1] = ($event) => logout())
                }, toDisplayString(unref(t)("user.logout")), 3)
              ]),
              createBaseVNode("div", _hoisted_5, [
                createBaseVNode("button", {
                  class: normalizeClass(["btn btn-danger", profile.value ? "" : "d-none"]),
                  onClick: _cache[2] || (_cache[2] = ($event) => clearLocalHistory())
                }, toDisplayString(unref(t)("session.clearData")), 3)
              ])
            ]),
            createBaseVNode("div", _hoisted_6, toDisplayString(unref(t)("help.tipMessage")), 1),
            createBaseVNode("div", _hoisted_7, [
              createBaseVNode("strong", null, [
                createTextVNode(toDisplayString(unref(t)("help.moreInfo")) + " TextDig ", 1),
                createBaseVNode("a", {
                  href: "#",
                  class: "fw-bold",
                  onClick: _cache[3] || (_cache[3] = ($event) => openHelp())
                }, toDisplayString(unref(t)("help.website")), 1)
              ])
            ]),
            lastError.value ? (openBlock(), createElementBlock("div", _hoisted_8, [
              createBaseVNode("div", _hoisted_9, [
                createVNode(Alert),
                createTextVNode(" " + toDisplayString(lastError.value), 1)
              ])
            ])) : createCommentVNode("", true)
          ])
        ])
      ]);
    };
  }
};
const App = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-81aa8bed"]]);
const LOG_ENABLED = "false";
const app = createApp(App);
const i18n = createI18n({
  locale: getUILanguage(),
  fallbackLocale: "en",
  messages: { en, es, nl, de, fr, it, pt },
  legacy: false
});
app.use(i18n);
app.use(entry_esm);
app.provide(Logger.KEY, new Logger(LOG_ENABLED));
app.mount("#app");
